
public class Test2 {

	public static void main(String[] args) {

		int operand = 10;
		ary = evenItemMultiply(ary, operand);
		// ��°��
		// [1, 20, 3, 40, 5, 60, 7, 80, 9, 100]
	}

	private static int[] evenItemMultiply(int[] ary, int operand) {

		return null;
	}
}
