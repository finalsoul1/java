
public class P279 {

	String name = "ȫ�浿";

	public static void main(String[] args) {
		say();
	}

	private static void say() {
		// #2 
		P279 p = new P279();
				
		System.out.println("�ȳ��ϼ��� " + p.name + "��!");
	}
}
