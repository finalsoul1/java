package exer;

public class e6_1 {

	public static void main(String[] args) {
		
	}

}
