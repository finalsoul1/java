package exer;

public class E6_5 {

	public static void main(String[] args) {
		Student s = new Student("ȫ�浿", 1, 1, 100, 60, 76);

		System.out.println(s.info());
	}

}

class Student {
	public Student(int... a) {
		
	}

	public char[] info() {
		return null; 
	}
}
