package p330;

public class Gilsoon extends HongFamily {

}
