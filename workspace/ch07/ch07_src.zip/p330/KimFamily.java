package p330;

public class KimFamily extends Korean{

	public void walk() {
		System.out.println("�ȴ´�.");
	}
}
