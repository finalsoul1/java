package p330;

public class Korean {
	String food = "��ġ";

	public Korean() {
		super();
		System.out.println("Korean() called.");
	}

	public void play() {
		System.out.println("���� ���.");
	}
}
