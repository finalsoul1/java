package p330;

public class LeeFamily extends Korean {

	public void walk() {
		System.out.println("�ȴ´�.");
	}
}
