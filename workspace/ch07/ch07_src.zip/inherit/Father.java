package inherit;

public class Father {
	String name;
	{
		name = "ù°";
	}
	public Father() {
		name = "1111";
	}

}
