package inherit;

public class Child extends Father {
	
	public String hobby = "soju";
	
	{
		name = "ưư��";
	}
	public Child() {
		name = "2222";
	}
}
