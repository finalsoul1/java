package p385;

public interface Flyable {
	public abstract void fly();
}
