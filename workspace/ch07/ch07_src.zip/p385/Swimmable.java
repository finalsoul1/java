package p385;

public interface Swimmable {
	public abstract void swim();
}
