package P370;

public class B {

}
