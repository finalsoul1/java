package p404;

public class SmallBox {

}
