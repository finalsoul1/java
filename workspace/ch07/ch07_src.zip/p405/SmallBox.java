package p405;

public class SmallBox {

}
